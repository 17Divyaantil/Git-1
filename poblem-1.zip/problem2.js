let mother_name = "Snehlata";
console.log(mother_name);