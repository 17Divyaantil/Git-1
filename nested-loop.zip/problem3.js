let details = {
  name   : "Divya",
  age    : 26,
  hobbies: ["coding", "travelling", "cycling"],
  smoking: false,
  location:"sonipat"
};
details.age = 35;
details["location"]="Delhi";
details.phone = "9875";
delete details.age;
delete details["name"];
console.log(details["hobbies"][1]);
