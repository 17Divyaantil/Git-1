let name="Lakshay";
let school="Hindu Vidyapeet";
let grade="10th";
let section="A";
let rollno=12;
let science_marks=88;
let maths_marks=98;
let english_marks=84;
console.log(name+"\n"+school+"\n"+grade+"\n"+section+"\n"+rollno+"\n"+science_marks+"\n"+maths_marks+"\n"+english_marks);
