

let name="Divya";
let age=26;
console.log(name,age);
console.log(typeof(name,age));
